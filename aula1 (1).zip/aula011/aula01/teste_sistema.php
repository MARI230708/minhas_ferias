<?php
//Configurações de conexão (Padrão do XAMPP)

$host = "localhost";
$usuario = "root";
$senha = "Senai@125";

//Testando a versão do PHP 
$versao_php = phpversion();

//Tentando conectar ao Banco de Dados (MySQL)
$conexao = new mysqli($host, $usuario, $senha);

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teste de Ambiente PHP</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>
    <div class="card">
    <h2>Status do Servidor Local</h2>
    <p>Versão do PHP instalada:<strong><?php echo $versao_php;?></strong></p>
    
<p>Status do MySQL:
            <?php if($conexao->connect_error): ?>
                <span class="erro">Erro ao conectar: <?php echo $conexao->connect_erro; ?></span>

            <?php else: ?>
                <span class="sucesso">Conectado com sucesso!</span>
            <?php endif; ?>
        </p>
    </div>


</body>
</html>